SBMA GOLDEN BACKUP - how to bring everything back
1. Make a new Supabase project (or use the existing one) and run setup-new-shop.sql, then every migration file (migration-3 ... latest) in the SQL Editor.
2. Put the new Supabase address and SERVICE key into sync-config.json, and the new address and anon key into Vercel (VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY), then redeploy.
3. Create the login user again in Supabase (Authentication > Users). Employee logins: add them again in Authentication > Users, then open each employee in the app (Staff > Edit) and save the login email again.
4. Double-click restore-golden.bat and give it this zip file. It puts all tables back.
5. Run run-sync.bat once to bring today's Profit Maker data.
This file contains customer, staff and sales data. Keep it private.